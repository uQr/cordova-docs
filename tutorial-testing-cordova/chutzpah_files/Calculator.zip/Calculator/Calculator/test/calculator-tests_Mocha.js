/*
describe("Calculator Mocha", function () {
    var calculator;
    beforeEach(function () {
        calculator = new Calculator();
    });

    it("can add", function () {
        var result = calculator.add(5, 5);
        expect(result).toBe(10);
    });

    it("can subtract", function () {
        var result = calculator.subtract(5, 5);
        expect(result).toBe(0);
    });

    it("can multiply", function () {
        var result = calculator.multiply(5, 5);
        expect(result).toBe(25);
    });

    it("can divide", function () {
        var result = calculator.divide(5, 5);
        expect(result).toBe(1);
    });
});
*/