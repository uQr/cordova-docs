﻿describe("Calculator Jasmine", function () {
    var calculator;
    beforeEach(function () {
        calculator = new Calculator();
    });
    
    it("can add", function () {
        expect(calculator.add(5, 5)).toEqual(10);
    });

    it("can subtract", function () {
        expect(calculator.subtract(5, 5)).toEqual(0);
    });
    it("can multiply", function () {
        expect(calculator.multiply(5, 5)).toEqual(25);
    });
    it("can divide", function () {
        expect(calculator.divide(5, 5)).toEqual(1);
    });
});
